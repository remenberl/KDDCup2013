#-*- coding: UTF-8 -*-

author_file = "./data/Author.csv"
paper_author_file = "./data/PaperAuthor.csv"
duplicate_authors_file = "./result/duplicate_authors.txt"

#Address for SOAP service
server_soap_address = "192.168.11.102"
client_soap_address = "jialu.cs.illinois.edu"

#Ports for SOAP service
server_port = 5900
client_port = 5900
