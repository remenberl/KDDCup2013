#-*- coding: UTF-8 -*-
from SOAPpy import SOAPProxy
from custom_setting import *

server = SOAPProxy(client_soap_address + ':' + str(client_port))

while True:
    author_name = raw_input("Type in the name of an author:\n")
    struct = server.handle_query(author_name)
    #Transform the structype provided by soappy to dict.
    struct_as_a_dict = dict((key, getattr(struct, key))
                            for key in struct._keys())
    exact_id_name_list = struct_as_a_dict['exact']
    possible_id_name_list = struct_as_a_dict['similar']
    print "Exact Match:"
    for (author_id, author_name) in exact_id_name_list:
        print " || " + author_name + ": " + str(author_id),
    print
    print "Similar:"
    for (author_id, author_name) in possible_id_name_list:
        print " || " + author_name + " " + str(author_id),
    print '\n'
